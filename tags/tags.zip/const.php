<?php

define("APP_DIR", __DIR__);
